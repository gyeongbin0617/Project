@echo off
setlocal
cd /d "%~dp0"
set "PARTY_GCC="
if defined MSYS2_ROOT if exist "%MSYS2_ROOT%\ucrt64\bin\gcc.exe" set "PARTY_GCC=%MSYS2_ROOT%\ucrt64\bin\gcc.exe"
if not defined PARTY_GCC if exist "C:\msys64\ucrt64\bin\gcc.exe" set "PARTY_GCC=C:\msys64\ucrt64\bin\gcc.exe"
if not defined PARTY_GCC if exist "D:\msys64\ucrt64\bin\gcc.exe" set "PARTY_GCC=D:\msys64\ucrt64\bin\gcc.exe"
if not defined PARTY_GCC (
  echo MSYS2 UCRT64 GCC was not found.
  echo Install the compiler in the MSYS2 UCRT64 terminal:
  echo pacman -S --needed mingw-w64-ucrt-x86_64-gcc
  echo For a custom install, set MSYS2_ROOT to your MSYS2 folder.
  pause
  exit /b 1
)
for %%G in ("%PARTY_GCC%") do set "PATH=%%~dpG;%PATH%"
echo Building Number Explorers 1.12...
"%PARTY_GCC%" -std=c11 -O2 -Wall -Wextra -Werror -Iinclude -Ivendor/include/SDL2 src/app.c src/app_input.c src/app_loop.c src/app_match.c src/audio.c src/background.c src/game.c src/i18n.c src/learn.c src/learn_ui.c src/main.c src/mistakes.c src/puzzle_ui.c src/puzzles.c src/review.c src/save.c src/scene_common.c src/scene_help.c src/scene_match.c src/scene_menu.c src/scene_shop.c src/scenes.c src/train.c src/train_ui.c src/ui.c -Lvendor/lib -lSDL2_image -lSDL2_ttf -lSDL2 -lm -static-libgcc -mwindows -o NumberExplorers_new.exe > build.log 2>&1
if errorlevel 1 (
  type build.log
  echo BUILD FAILED. See the error above.
  pause
  exit /b 1
)
move /y "NumberExplorers_new.exe" "NumberExplorers.exe" >nul
if errorlevel 1 (
  echo Close the running game, then build again.
  pause
  exit /b 1
)
echo BUILD OK. Run NumberExplorers.exe or RUN.bat.
pause
